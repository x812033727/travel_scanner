# 第 52 篇：原始練習與 2026-09-15 實測增補

original/ 保留原作者練習，內有 not_run 的空白表是供重做使用，不是本輪實測狀態。
live/ 保存這輪模型產物及證據；environment.json 與 capture-audit.json 記錄環境和限制。
evidence-index.json 保存來源檔案與 SHA256。解壓後執行 python verify_archive.py 檢查保存位元組。
這個檢查不重新呼叫 Google、不驗證雲端目前狀態，也不等於人工語意核准。

第 52 篇：original/ 手冊與題庫；live/raw/ 原始 v1/v2 共 24 份，live/corrected/raw/ 修正後 12 份。
第 53 篇：original/ 作者參考工具；live/budget-v4.html 是本次模型成品，前版失敗另存。
第 54 篇：original/ 合成信與檢查器；live/ 的文件文字和試算表 TSV 是介面擷取。
candidate-normalized.csv 是 Codex 衍生資料。
只會包含本篇對應檔案。完整實測報告在 repository 的 work/verification/live-20260915/52/。

原作者練習授權見 original/LICENSE.txt。實測檔案標示為模型輸出或觀察，不冒稱 Google 官方文件。
本包尚未公開；文章與整套發布仍須其他驗收。沒有附帳號、金鑰或私人雲端連結。
