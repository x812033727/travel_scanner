"""Verify bundled bytes; this does not rerun Google or approve model quality."""
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
entries = json.loads((base / "evidence-index.json").read_text(encoding="utf-8"))
for entry in entries:
    path = (base / entry["archivePath"]).resolve()
    assert path.is_relative_to(base), entry["archivePath"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["sha256"], entry["archivePath"]
print(f"Verified {len(entries)} bundled files. Semantic approval and publication remain pending.")
