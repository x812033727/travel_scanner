# 第 58 篇練習與實測

original/58 是作者參考教材，live/ 是三次真實回答、三份筆記、引用與修正。CSV 由保存的模型文字整理，不是產品直接匯出。假引用與錯誤主張是離線故障。

解壓後在本目錄執行 python verify_archive.py 檢查保存位元組；執行 python original/research_checks.py evidence original/58 核對原教材。

故障練習：python original/research_checks.py evidence live/fault-lab/reviewed；把尾端 reviewed 換成 fake-quote，預期拒絕 fabricated_quote；換 bad-claim 時字串檢查仍通過，人工必須拒絕 54 人；repaired 還原後通過。上述指令均不呼叫 Google。live 內重建腳本與 README 的相對連結需於 repository 使用。

原始回答仍有章節層級及表格換行問題，詳見 live/README.md。沒有私人雲端連結或金鑰。未公開；授權見 original/58/LICENSE.txt。
