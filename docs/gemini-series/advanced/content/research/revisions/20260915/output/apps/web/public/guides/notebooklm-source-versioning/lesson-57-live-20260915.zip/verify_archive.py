"""Verify bundled bytes without making Google calls."""
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
entries = json.loads((base / "evidence-index.json").read_text("utf-8"))
for entry in entries:
    path = (base / entry["archivePath"]).resolve()
    assert path.is_relative_to(base)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["sha256"], path
print(f"Verified {len(entries)} bundled files. No cloud calls or publication.")
