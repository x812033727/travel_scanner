# Actual lesson 89 Teams result

Code was produced by the named product teammates. The integrator owns task-contract.md.
The verifier performed the browser checks and three separate independent assertions.
Run `node --test tests/model.test.mjs tests/filter.test.mjs` (10 tests), then `node server.mjs`.
Stop the local server with Ctrl+C. No publication, remote commit or deployment was performed.
