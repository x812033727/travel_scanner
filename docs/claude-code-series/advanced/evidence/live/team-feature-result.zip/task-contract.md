# 任務合約：待辦狀態篩選（Issue #104）

規則識別碼：MOKAAIR-LAB-61

## 函式簽名

```js
selectTodos(items, mode)
```

- `items`：待辦陣列，**不得原地修改**（no mutation）— 必須回傳新陣列，`items` 本身維持不變。
- `mode`：篩選模式字串。
- 回傳：篩選後的新陣列。

## 支援模式

| mode 值 | 行為 |
| --- | --- |
| `'all'` | 回傳所有項目 |
| `'active'` | 只回傳 `completed === false` 的項目 |
| `'completed'` | 只回傳 `completed === true` 的項目 |
| 其他未知字串 | **尚未決定（UNDECIDED）— 見下方** |

## 未知 mode 行為：已裁示（DECIDED）

`mode` 不是 `'all' | 'active' | 'completed'` 時，`selectTodos` **回退（fallback）為顯示所有項目**（等同 `'all'` 的結果）：回傳一個全新陣列，內容為所有項目，且不得修改傳入的 `items` 或其中的物件。

- 負責實作與測試：**data-builder**（僅限 `filter.js` / `tests/filter.test.mjs`）。
- ui-builder 不需（也不應）為此變更修改 `filter.js` 或資料測試；UI 端三個按鈕仍只會傳入 `'all'`/`'active'`/`'completed'` 這三個合法字串，未受此裁示影響。

## 身分識別與資料規則

- 一律以 `id` 辨認項目；同名待辦（相同 title）可以並存，不可用 title 去重或比對。
- `selectTodos` 不得修改傳入的 `items` 陣列或其中的物件（no mutation）。
- 畫面顯示標題必須使用 `textContent`，不得以 innerHTML 等方式解讀使用者輸入文字。

## 檔案分工（不得越界）

- **data-builder** 僅能修改：`filter.js`、`tests/filter.test.mjs`
- **ui-builder** 僅能修改：`app.js`、`index.html`、`style.css`
- 兩者皆 **不得修改** `model.js`、`tests/model.test.mjs`（維持原樣）
- 不得以參考資料整批取代 starter 現有檔案。

## 驗證

- 核心驗證命令：`node --test tests/model.test.mjs`
- 新功能驗證：`node --test tests/filter.test.mjs`
- 整合驗證（由整合者於裁示後執行）：`node --test tests/model.test.mjs tests/filter.test.mjs` 及 `git diff --check`
- 兩位團隊成員回報時，須列出實際變更的檔案路徑與已執行的測試。

## 狀態

- [x] 未知 mode 行為：已裁示 — 回退顯示所有項目（fallback to all），由 data-builder 實作與測試
- [x] label 變更：已裁示 — 「全部」按鈕文字改為「所有待辦」，`data-mode="all"` 與目前的全量統計數字（status count）維持不變，由 ui-builder 實作
