export function selectTodos(items, mode) {
  if (mode === 'all') return [...items];
  if (mode === 'active') return items.filter(item => item.completed === false);
  if (mode === 'completed') return items.filter(item => item.completed === true);
  // 未知 mode：回退為顯示所有項目（等同 'all'），依 task-contract.md 裁示。
  return [...items];
}
