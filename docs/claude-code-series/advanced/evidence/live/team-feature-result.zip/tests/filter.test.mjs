import { test } from 'node:test';
import assert from 'node:assert/strict';
import { selectTodos } from '../filter.js';

test('mode 為 all 時回傳所有項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: false },
    { id: 'b', title: '讀書', completed: true },
  ];
  const result = selectTodos(original, 'all');
  assert.deepEqual(result, original);
});

test('mode 為 active 時只回傳未完成項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: false },
    { id: 'b', title: '讀書', completed: true },
    { id: 'c', title: '洗衣服', completed: false },
  ];
  const result = selectTodos(original, 'active');
  assert.deepEqual(result, [
    { id: 'a', title: '買早餐', completed: false },
    { id: 'c', title: '洗衣服', completed: false },
  ]);
});

test('mode 為 completed 時只回傳已完成項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: false },
    { id: 'b', title: '讀書', completed: true },
    { id: 'c', title: '洗衣服', completed: true },
  ];
  const result = selectTodos(original, 'completed');
  assert.deepEqual(result, [
    { id: 'b', title: '讀書', completed: true },
    { id: 'c', title: '洗衣服', completed: true },
  ]);
});

test('selectTodos 不得修改傳入的陣列或其中的項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: false },
    { id: 'b', title: '讀書', completed: true },
  ];
  const snapshot = original.map(item => ({ ...item }));
  selectTodos(original, 'all');
  selectTodos(original, 'active');
  selectTodos(original, 'completed');
  assert.deepEqual(original, snapshot);
  assert.equal(original.length, 2);
});

test('未知 mode 時回退為顯示所有項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: false },
    { id: 'b', title: '讀書', completed: true },
  ];
  const snapshot = original.map(item => ({ ...item }));
  const result = selectTodos(original, 'bogus');
  assert.deepEqual(result, original);
  assert.deepEqual(original, snapshot);
  assert.equal(original.length, 2);
});

test('以 id 辨認項目，同名待辦（相同 title）可並存且不會被去重', () => {
  const original = [
    { id: 'a', title: '相同標題', completed: false },
    { id: 'b', title: '相同標題', completed: true },
  ];
  const active = selectTodos(original, 'active');
  const completed = selectTodos(original, 'completed');
  assert.deepEqual(active, [{ id: 'a', title: '相同標題', completed: false }]);
  assert.deepEqual(completed, [{ id: 'b', title: '相同標題', completed: true }]);
  assert.equal(selectTodos(original, 'all').length, 2);
});
