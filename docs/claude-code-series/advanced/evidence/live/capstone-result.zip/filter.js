export function filterTodos(items, mode) {
  if (mode === 'active') return items.filter(item => !item.completed);
  if (mode === 'completed') return items.filter(item => item.completed);
  return items.slice();
}
