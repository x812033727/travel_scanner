import { test } from 'node:test';
import assert from 'node:assert/strict';
import { filterTodos } from '../filter.js';

test('all 模式回傳完整來源資料且不修改原陣列', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: true },
    { id: 'b', title: '讀書', completed: false }
  ];
  const filtered = filterTodos(original, 'all');
  assert.deepEqual(filtered, original);
  assert.notEqual(filtered, original);
  assert.equal(original.length, 2);
});

test('active 模式只回傳未完成項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: true },
    { id: 'b', title: '讀書', completed: false }
  ];
  const filtered = filterTodos(original, 'active');
  assert.deepEqual(filtered, [{ id: 'b', title: '讀書', completed: false }]);
  assert.equal(original.length, 2);
});

test('completed 模式只回傳已完成項目', () => {
  const original = [
    { id: 'a', title: '買早餐', completed: true },
    { id: 'b', title: '讀書', completed: false }
  ];
  const filtered = filterTodos(original, 'completed');
  assert.deepEqual(filtered, [{ id: 'a', title: '買早餐', completed: true }]);
  assert.equal(original.length, 2);
});

test('未知 mode 回傳全部項目', () => {
  const original = [{ id: 'a', title: '買早餐', completed: true }];
  const filtered = filterTodos(original, 'unknown-mode');
  assert.deepEqual(filtered, original);
});

test('同名待辦以 id 分別篩選', () => {
  const original = [
    { id: 'a', title: '相同標題', completed: false },
    { id: 'b', title: '相同標題', completed: true }
  ];
  const active = filterTodos(original, 'active');
  const completed = filterTodos(original, 'completed');
  assert.deepEqual(active, [{ id: 'a', title: '相同標題', completed: false }]);
  assert.deepEqual(completed, [{ id: 'b', title: '相同標題', completed: true }]);
});
