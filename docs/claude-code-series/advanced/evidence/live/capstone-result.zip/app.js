import { addTodo, toggleTodo, removeTodo } from './model.js';
import { filterTodos } from './filter.js';

const STORAGE_KEY = 'mokaair-capstone-96';

const form = document.querySelector('#todo-form');
const input = document.querySelector('#todo-title');
const list = document.querySelector('#todo-list');
const message = document.querySelector('#message');
const filterButtons = document.querySelectorAll('[data-filter]');
let items = loadItems();
let filterMode = 'all';

function loadItems() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(item => item && typeof item.id === 'string' && typeof item.title === 'string' && typeof item.completed === 'boolean');
  } catch {
    return [];
  }
}

function saveItems() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    // 儲存失敗時忽略，畫面仍以記憶體資料運作。
  }
}

function render() {
  list.replaceChildren();
  for (const button of filterButtons) {
    button.setAttribute('aria-pressed', String(button.dataset.filter === filterMode));
  }
  const visible = filterTodos(items, filterMode);
  for (const item of visible) {
    const row = document.createElement('li');
    const label = document.createElement('label');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = item.completed;
    checkbox.addEventListener('change', () => { items = toggleTodo(items, item.id); saveItems(); render(); });
    const title = document.createElement('span');
    title.textContent = item.title;
    if (item.completed) title.className = 'completed';
    label.append(checkbox, title);
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.textContent = '刪除';
    remove.setAttribute('aria-label', `刪除 ${item.title}`);
    remove.addEventListener('click', () => { items = removeTodo(items, item.id); saveItems(); render(); });
    row.append(label, remove);
    list.append(row);
  }
  if (!items.length) {
    message.textContent = '目前沒有待辦。';
  } else if (!visible.length) {
    message.textContent = '此篩選條件下沒有項目。';
  } else {
    message.textContent = `共 ${items.length} 件，已完成 ${items.filter(item => item.completed).length} 件`;
  }
}
form.addEventListener('submit', event => {
  event.preventDefault();
  const next = addTodo(items, input.value, crypto.randomUUID());
  if (next === items) { message.textContent = '請輸入一到一百字的待辦。'; return; }
  items = next;
  saveItems();
  input.value = '';
  render();
  input.focus();
});
for (const button of filterButtons) {
  button.addEventListener('click', () => {
    filterMode = button.dataset.filter;
    render();
  });
}
render();
