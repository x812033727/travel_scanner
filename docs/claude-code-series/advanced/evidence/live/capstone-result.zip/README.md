# Claude 實際產生的第 96 篇本機成果

此包來自 lesson-96 starter。Claude Code 2.1.233（Sonnet）完成篩選、UI、保存與測試；指定故障由另一個 Haiku 工作階段修正。Codex 另作獨立測試、瀏覽器驗收、乾淨解壓縮重驗，並更正 handoff 一句資料過濾說明。這不是替換教材 reference 的另一份手工完成版。

需要 Node.js 22 以上，不需要安裝依賴或資料庫：

```powershell
node --test tests/model.test.mjs tests/filter.test.mjs
$env:CAPSTONE_DIRECTORY=(Get-Location).Path
node --test verification/capstone-acceptance.test.mjs
node server.mjs
```

開啟輸出的 localhost 網址。按 Ctrl+C 停止該伺服器。課程 localStorage key 為 mokaair-capstone-96。沒有帳號、遠端同步、部署或私人資料。

原始模型操作與失敗／修正紀錄保存於教學儲存庫 advanced/evidence/live。手機寬度模擬已測，實體手機與跨裝置接續仍未驗證。
