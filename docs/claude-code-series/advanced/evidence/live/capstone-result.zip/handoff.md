# Handoff：合成待辦篩選驗收

## 變更檔案
- `filter.js`（新增）：匯出 `filterTodos(items, mode)`，支援 `all`／`active`／`completed`，未知 mode 回傳全部；不修改傳入陣列（回傳新陣列）。
- `tests/filter.test.mjs`（新增）：驗證 all／active／completed／未知 mode／同名待辦分別篩選，且不原地修改來源資料。
- `tests/model.test.mjs`：未修改。
- `app.js`：
  - 匯入 `filterTodos`，render 時才依 `filterMode` 篩選畫面（資料本身維持完整）。
  - 新增 `loadItems()` / `saveItems()`，使用 `localStorage`，key 為 `mokaair-capstone-96`。
  - `loadItems()` 遇到非陣列或 JSON 損壞時回復空陣列；合法陣列中只移除欄位型別不符的項目，保留其餘合法項目。（Codex 依實作更正原交接文字。）
  - 新增、切換、刪除後皆呼叫 `saveItems()` 立即保存。
  - 篩選按鈕透過 `aria-pressed` 標示目前選取狀態。
  - 標題仍以 `textContent` 顯示，未變更為 innerHTML，避免使用者輸入被當成 HTML 解析。
- `index.html`：加入 `.filters` 區塊，三顆有名稱（`全部`／`未完成`／`已完成`）且帶 `aria-pressed` 狀態的按鈕；保留原有 `#todo-title`、`#todo-form`、`#todo-list`、`#message`。
- `style.css`：未修改（既有 `.filters` 與 `aria-pressed` 樣式規則已存在，直接沿用）。

## 已執行的檢查
- `node --test tests/model.test.mjs tests/filter.test.mjs` → 9 項測試全數通過（原有 4 項模型測試 + 新增 5 項篩選測試）。

## localStorage
- Key：`mokaair-capstone-96`
- 內容：完整 `items` 陣列（含 `id`／`title`／`completed`），與畫面篩選狀態無關（篩選狀態只影響顯示，不保存）。
- 損壞或格式錯誤時，`loadItems()` 會回傳空陣列，畫面可正常新增/操作，不會卡死。

## 停止方式
- 本任務未啟動任何常駐伺服器、未安裝套件、未執行 Git 操作、未連外部服務。純靜態檔案修改，無需額外停止步驟。

## 未驗證項目（重要）
- **尚未在瀏覽器中實際開啟 `index.html` 測試。** 以下項目僅透過程式碼閱讀與邏輯檢查，未經真人瀏覽器互動驗證：
  - 篩選按鈕點擊後畫面是否正確切換、`aria-pressed` 視覺樣式是否符合預期。
  - 新增／切換／刪除後重新整理頁面，`localStorage`（key `mokaair-capstone-96`）資料是否確實保留。
  - 手動寫入損壞的 `localStorage` 內容後，重新整理是否確實回復為可操作的空清單。
  - 360–390px 寬度下是否整頁無水平捲動（僅由既有 CSS 的 `flex-wrap`、`min-width:0`、`clamp()` 規則推斷應可通過，未實測）。
  - 表單空白／過長輸入的錯誤訊息在畫面上的實際呈現。
- 建議下一步：以瀏覽器（或含 DOM 的自動化工具）開啟 `index.html`，手動或以腳本驗證上述互動與版面行為。

## 獨立驗收補充

後續由 Codex 在內建瀏覽器驗證三種篩選、同名項目、刷新保存、360／390px、空白輸入與損壞 JSON 恢復。指定比較符號反轉已在 UI 重現，Claude 修正後相同獨立斷言轉綠。這些是本機與瀏覽器尺寸模擬，不是真實手機。原先 Claude 未經瀏覽器驗證的報告仍保存於 capstone-implementation.json。

啟動：node server.mjs；停止：在該終端機按 Ctrl+C。使用專案規則與核心測試，不需要額外 Skill、Hook、MCP 或 SDK 來完成本次本機功能。未部署或推送遠端。
