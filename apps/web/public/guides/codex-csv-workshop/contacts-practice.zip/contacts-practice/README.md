# CSV practice / CSV 練習 / CSV 练习 / CSV 実習 / CSV 실습

Reference files use fictional data only. Keep contacts.csv unchanged and use a new output filename each time.
參考程式只使用虛構資料。保留 contacts.csv，每次指定新的輸出檔名。完整五語操作與限制見下方教學。
参考程序只使用虚构数据。保留 contacts.csv，每次指定新的输出文件名。完整五语操作与限制见下方教程。
架空資料だけの参考実装です。contacts.csv を保持し、毎回新しい出力名を使います。全手順と制限は下記の教材にあります。
가상 자료만 쓰는 참고 코드입니다. contacts.csv를 보존하고 매번 새 출력 이름을 사용하세요. 전체 절차와 제한은 아래 학습 자료에 있습니다.

Requires Python 3.9 or later / 需要 Python 3.9 以上版本 / 需要 Python 3.9 及以上版本 / Python 3.9 以降が必要 / Python 3.9 이상 필요.

## Windows PowerShell
```powershell
py -3 clean_contacts.py contacts.csv cleaned-01.csv
py -3 -m unittest -v test_clean_contacts.py
```

## macOS / Linux
```sh
python3 clean_contacts.py contacts.csv cleaned-01.csv
python3 -m unittest -v test_clean_contacts.py
```

Expected / 預期 / 预期 / 期待 / 예상: kept=2, duplicate=1, invalid=1; 3 passing tests.
This writes a local output; it sends no email and does not publish anything.
教學 / 教程 / Tutorial / 教材 / 학습: https://mokaair.com/en/life/codex-csv-workshop
Use the site's language switcher for zh-TW, zh-CN, en, ja and ko.
