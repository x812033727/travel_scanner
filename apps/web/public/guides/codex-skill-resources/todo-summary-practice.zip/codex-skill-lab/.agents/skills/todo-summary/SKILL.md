---
name: todo-summary
description: Summarize a local task JSON array with verified counts. Use for task-count reports, not for editing tasks, website styling, or deployment.
---

# Todo summary

1. Confirm the practice root and the exact input path with the user request.
2. Read [the input contract](references/input-format.md).
   If any required resource is missing or unreadable, stop and report it.
3. Read [the checker](scripts/count-tasks.mjs) before running it.
4. From the practice root, run:

   ```sh
   node .agents/skills/todo-summary/scripts/count-tasks.mjs data/tasks.json
   ```

   Replace the input argument only if the request names another input file.
5. If the command fails, report the actual error. Do not guess counts or repair input.
6. If it succeeds, use [the report template](assets/report.md) in the reply.
7. Include the actual command, exit code and input-preservation check.
   Say which checks were not performed. Do not claim browser testing.
8. Do not edit source data, skill resources, or project code, and do not publish.
