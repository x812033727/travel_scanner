import { readFileSync } from 'node:fs';

try {
  if (process.argv.length !== 3) {
    throw new Error('Usage: node count-tasks.mjs <input.json>');
  }
  const tasks = JSON.parse(readFileSync(process.argv[2], 'utf8'));
  if (!Array.isArray(tasks)) throw new Error('Input must be an array');
  const ids = new Set();
  for (const [index, task] of tasks.entries()) {
    if (!task || typeof task !== 'object'
      || typeof task.id !== 'string' || !task.id.trim()
      || typeof task.title !== 'string' || !task.title.trim()
      || typeof task.completed !== 'boolean') {
      throw new Error(`Invalid task at index ${index}`);
    }
    if (ids.has(task.id)) throw new Error(`Duplicate id: ${task.id}`);
    ids.add(task.id);
  }
  const completed = tasks.filter(task => task.completed).length;
  const result = { total: tasks.length, active: tasks.length - completed, completed };
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
} catch (error) {
  process.stderr.write((error instanceof Error ? error.message : String(error)) + '\n');
  process.exitCode = 1;
}
