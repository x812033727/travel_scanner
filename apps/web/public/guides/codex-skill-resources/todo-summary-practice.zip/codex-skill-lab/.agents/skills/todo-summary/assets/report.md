# Task summary

Input: <relative input path>
Command: <exact command>
Exit code: <observed exit code>
Total: <observed total>
Active: <observed active>
Completed: <observed completed>
Input preserved: <verification and result>
Not checked: <remaining checks>
