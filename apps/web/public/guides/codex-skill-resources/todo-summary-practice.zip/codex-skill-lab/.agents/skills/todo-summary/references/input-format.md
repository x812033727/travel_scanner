# Task input contract

- Input is a JSON array. An empty array is valid.
- Each record has a nonempty string id, a nonempty string title,
  and a boolean completed value.
- IDs are unique. Repeated titles are allowed and remain separate.
- Extra fields may be present; the summary ignores them.
- Invalid input must fail; do not silently drop or repair records.
- Read input only. Do not change, sort or overwrite the source file.
- Report total, active and completed. total = active + completed.
