這一篇建立可以下載審查結果的 GitHub Actions 練習：PR 只執行沒有模型秘密的基準測試，模型審查由預設分支手動觸發，輸出通過結構驗證後才保存成附件。你會核對真正的 workflow run、來源提交與取消狀態，避免只貼 YAML 就宣稱 CI 已完成。

先讀[GitHub Actions 入門](article:claude-code-github-actions)、[資料安全](article:claude-code-project-data-safety)及[JSON 流程](article:claude-code-structured-cli-pipeline)。下載[第 92 篇材料](https://mokaair.com/tutorials/claude-code/advanced/lesson-92.zip)。需要可寫的獨立測試儲存庫、GitHub Actions 使用權限，以及受控的 Claude API 認證。閱讀約 20 分鐘，實作約 75 分鐘。

## 先看觸發範圍與權限表

下載包的 automation/ci/review.yml 有 baseline 與 model-review 兩個工作。baseline 在 PR 或手動事件執行核心測試；model-review 只接受預設分支的 workflow_dispatch，並使用 claude-lab 環境。外部 fork PR 不會進入模型工作，也沒有傳入模型秘密。

本課模型只審查預設分支中的固定 fixtures/toggle.diff，不讀取或執行任意 PR 分支程式。這是可控的第一個 CI 審查實驗；若要擴充成自動審查外部 PR，需要另設可信任的工作流、資料取得與授權邊界，不能只移除條件就完成安全整合。

| 工作 | 來源 | 需要的資料與權限 |
|---|---|---|
| baseline | PR 或手動事件 | 儲存庫唯讀、無模型秘密 |
| model-review | 預設分支手動事件 | 固定假資料、環境中的模型金鑰 |
| artifact | 通過驗證的 JSON | 只上傳 review.json |

workflow 的 contents 權限是 read，checkout 不保存憑證，模型工具限制為 Read。這些條件縮小課程範圍，但仍應保護環境秘密與可修改 workflow 的權限。不要把未知 PR 的程式切到有秘密的工作中執行，也不使用 pull_request_target 來繞過 fork 的限制。

## 先建立沒有模型的基準

將 starter 內容放入你已授權的測試儲存庫，先確認核心測試在本機通過。將 review.yml 複製到 .github/workflows/claude-lab.yml，第一輪可以只保留 baseline 工作。提交後建立一個測試 PR，查看 Actions 是否真的執行。

```yaml .github/workflows/claude-lab.yml：第一輪最小基準
name: Claude lab baseline
on: [pull_request, workflow_dispatch]
permissions:
  contents: read
jobs:
  baseline:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@11d5960a326750d5838078e36cf38b85af677262
        with:
          persist-credentials: false
      - uses: actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020
        with:
          node-version: '22'
      - run: node --test tests/model.test.mjs
```

保存 run URL、來源 SHA、分支、事件與退出結果。只看到工作流檔案出現在 GitHub，不代表它已執行；綠色提交標記也要確認是哪一個檢查。第一次故意在測試分支注入已知 toggle 錯誤，確認 baseline 真的變紅，再修正並重跑。

上方 actions 使用完整提交識別碼，是本課查證時的固定版本。未來更新應重新核對來源與測試，不把完整 SHA 視為永遠安全或永不需要維護。下載材料中的完整工作流也固定 Claude action 的提交。

## 加入環境認證與模型工作

在測試儲存庫建立 claude-lab environment，將部署分支限制到預設分支，依團隊需要設定人工審核，再把 API 金鑰放入該環境的 ANTHROPIC_API_KEY secret。不要寫進 YAML、PR 正文或一般輸出日誌，也不要把 production 的憑證拿來做課程實驗。

將材料的完整 review.yml 套用到工作流位置，閱讀 model-review 的 if 條件與 environment。它在 baseline 成功後執行，timeout 十分鐘，Claude 呼叫另外限制三回合與練習預算。多層上限用途不同，不能只靠一個 token 設定保證程序一定停止。

```yaml 完整材料中 model-review 的關鍵條件
if: github.event_name == 'workflow_dispatch' && github.ref == format('refs/heads/{0}', github.event.repository.default_branch)
needs: baseline
runs-on: ubuntu-latest
timeout-minutes: 10
environment: claude-lab
```

這個片段是說明位置，不能單獨當成完整工作流貼到根目錄。完整可操作版本已包含 checkout、固定 action、提示詞、JSON Schema、結果保存和附件上傳。先逐行核對它讀取的檔案都在測試儲存庫中，再手動執行。

## 結構驗證後才保存附件

Claude action 的 structured_output 傳入 REVIEW_JSON 環境變數，由 automation/ci/save-review.mjs 解析。程式要求非空 summary 與 findings 字串陣列，再只保留這些欄位寫到 run-data/review.json。空值或錯誤型別會使步驟失敗，不會上傳一份看似成功的空報告。

```javascript 觀察用的結果驗證邏輯
const value=JSON.parse(process.env.REVIEW_JSON??'');
if(typeof value.summary!=='string'||!value.summary.trim()||!Array.isArray(value.findings)){
  throw new Error('Invalid review output');
}
```

正式材料還檢查 findings 的每個項目型別，並只上傳指定 review.json。不要上傳整個工作目錄、原始 session 或完整執行檔，因為工具輸出可能包含不適合公開的資料。show_full_output 與 display_report 在課程工作流中保持關閉。

結構合法不代表內容正確。下載附件後，仍要人工檢查比較符號的變更、具體觸發條件及是否誠實說明未執行測試。不要因為 JSON Schema 通過，就把模型審查當成已證實缺陷或自動合併依據。

## 實際觸發、失敗與取消

在 Actions 選取課程工作流，確認使用預設分支，再手動觸發。若環境要求審核，先核對這次 SHA 與內容；開始後觀察 baseline、模型呼叫、結果驗證及附件四個階段。每個階段都可能獨立失敗，需要對應的紀錄。

```text 已登入 gh 的測試儲存庫終端機：唯讀查看結果
gh run list --workflow claude-lab.yml --limit 5
```

找到實際 run id 後，再用 gh run view 查看狀態，或在 GitHub 介面開啟該次執行。不要照抄別人的 run id。測試取消時，在執行中的課程 run 使用取消控制，確認最後狀態是 cancelled，並查看附件是否真的產生，不能假定被取消仍有完整結果。

故障練習可暫時移除測試環境的模型認證，觀察模型工作失敗但沒有產生合法審查附件；恢復後再重跑。不要把金鑰列印出來確認是否存在。若第一次請求可能已計費，紀錄實際失敗與重試，別將失敗用量當成零。

## fork 情境與維護

在有權限的測試情境建立 fork PR，核對只執行 baseline、模型工作被條件排除。這份課程沒有讓 fork 取得模型 secret；若你後來擴充流程，應重新驗證這個界線。也不要把未受信任 PR 的正文直接插進可執行 shell 指令。

| 故障 | 先查什麼 |
|---|---|
| 沒有 run | workflow 路徑、觸發事件、預設分支 |
| 基準紅燈 | 實際測試命令與來源 SHA |
| 模型認證失敗 | environment、secret 名稱、授權 |
| 沒有附件 | 模型是否完成、JSON 驗證、上傳路徑 |
| 取消後仍有其他工作 | concurrency 範圍及各 run 狀態 |

完成應有實際 run、固定 action 版本、下載的合法附件、故障和取消紀錄，以及 fork 不進模型工作的證據。只有本機 YAML 檢查時，狀態應寫「工作流材料完成，遠端 CI 待測」。小練習是修改 Schema 讓缺少 summary 的結果被拒絕，確認它不會被當成完成，再把恢復方式記入[排程可靠性](article:claude-code-scheduled-workflow-reliability)的操作手冊。
