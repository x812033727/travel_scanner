# 可追蹤、可恢復的自動化

每個 lesson ZIP 可獨立解壓縮；先讀各包 README 與 article.md。
