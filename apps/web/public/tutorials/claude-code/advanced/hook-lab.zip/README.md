# Hooks 事件、檢查與故障處理

每個 lesson ZIP 可獨立解壓縮；先讀各包 README 與 article.md。
