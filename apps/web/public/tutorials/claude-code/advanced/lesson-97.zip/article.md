設定檔裡的 Hook 在 Claude Code 外部執行。想在行程內數工具呼叫、把次數顯示在 spinner 旁，文件的做法是 mod。本篇照官方教學建立 first-mod：三個檔案、四個事件函式，再用 `claude plugin validate` 看 Claude Code 讀到什麼、用 `claude plugin test` 寫不需要 session 的測試。交付是能載入的 first-mod、一個通過的測試，與驗證器的 hooks、calls 兩行紀錄。

先讀 [Plugins 入門](article:claude-code-plugins-guide)、[建立第一個 Hook](article:claude-code-hooks-getting-started)與[Plugin 打包](article:claude-code-plugin-team-distribution)。下載[第 97 篇材料](https://mokaair.com/tutorials/claude-code/advanced/lesson-97.zip)，在 starter 的 `first-mod` 操作：它只有 plugin.json 與 hooks.json，其餘由你寫，reference 有四個檔可對照。需要 Claude Code v2.1.287 or later（用 `claude --version` 檢查）；互動試用需要你自己登入的 Claude Code，validate 與 test 不需要 session。閱讀約 20 分鐘，實作約 40 分鐘。

## mod 是什麼，和設定檔 Hook 差在哪

文件把 mod 定義成多了入口檔的 plugin：入口檔叫 hooks module，Claude Code 在事件發生時呼叫裡面的函式，函式可以觀察、改寫或接手事件。

用詞先講清楚：官方文件把 mod 的事件處理函式與設定檔的 settings hook 都叫 hook。本篇固定稱後者「設定檔 Hook」、前者「mod 的事件函式」。設定檔 Hook 在行程外運作、不能畫進介面；mod 在行程內，可畫 pane 或改寫 spinner。

## 寫三個檔案

plugin.json 是一般的 manifest，mod 沒有額外必填欄位。hooks.json 的 `modules` 是只放一個相對路徑的陣列，文件說有了它才算 mod。register.js 是入口。

```text 編輯器：確認目錄結構
first-mod/
├── .claude-plugin/
│   └── plugin.json
├── hooks/
│   ├── hooks.json
│   └── register.js
└── tests/
    └── first-mod.test.ts
```

```json 寫入 first-mod/.claude-plugin/plugin.json
{
  "name": "first-mod",
  "version": "0.1.0",
  "description": "Counts Claude's tool calls, shows the count beside the spinner, and adds a /tally command",
  "author": { "name": "Mokaair tutorial" }
}
```

```json 寫入 first-mod/hooks/hooks.json
{
  "description": "The first-mod hooks module",
  "modules": ["./register.js"]
}
```

```javascript 寫入 first-mod/hooks/register.js
// The count, shared by the hooks below
let calls = 0

// Claude Code calls this once when the mod loads
export function register(on) {
  // Runs when the session starts, before your first prompt
  on('session.start', async ($, e, next) => {
    // Add the /tally command
    await $.command.register({
      name: 'tally',
      description: 'Show how many tool calls Claude has made',
    })
    // Let the session start as usual
    return next(e)
  })

  // Runs each time Claude is about to use a tool
  on('tool.call', async ($, e, next) => {
    calls += 1
    // Ask Claude Code to draw the interface again, so the new count shows
    $.ui.invalidate('ui.render')
    // Let the tool run as usual
    return next(e)
  })

  // Runs when you type /tally, and only then, because of the matcher
  on('command.run', { command: 'tally' }, async () => {
    // The text to print in the transcript
    return { text: 'Claude has made ' + calls + ' tool calls since this mod loaded' }
  })

  // Runs each time Claude Code draws the spinner
  on('ui.render', { component: 'Spinner' }, async ($, e, next) => {
    // Keep Claude Code's spinner, with the count added after its word
    return next({ ...e, props: { ...e.props, suffix: ' · tool calls: ' + calls + '…' } })
  })
}
```

`session.start` 註冊 /tally，`tool.call` 計數並要求重畫，`command.run` 只在 /tally 時回覆，`ui.render` 把次數接在 spinner 字後。

每個事件函式拿到三個引數：`$` 是 mods API，能呼叫的方法都在上面；`e` 是凍結的事件資料，要改就傳複本；`next` 把事件交給後面的 mod 與 Claude Code 自己的行為。處理有三種：觀察（回傳 `next(e)`）、接手（如 `command.run`，不呼叫 `next`，第二個引數 `{ command: 'tally' }` 是 matcher）、改寫（如 `ui.render`，把複本交給 `next`）。

## 載入並試用

用 `--plugin-dir` 載入，只限這一次 session，不會安裝。

```text 專案終端機：載入 first-mod
claude --plugin-dir ./first-mod
```

```text Claude Code 對話框：要求幾次工具呼叫
請列出這個資料夾的檔案，再讀 README。
```

文件說明的預期：spinner 字後有往上數的次數，如 `Thinking · tool calls: 2…`；/tally 預期回覆次數，文字前有 `first-mod:`。`claude -p` 不畫介面，預期印出 0 次；`/plugin` 的 Installed 分頁預期列出 mod，分頁下方有 `1 mod active · first-mod`。

```text 專案終端機：非互動檢查 /tally
claude -p "/tally" --plugin-dir ./first-mod
```

以上是文件的預期。本站只在容器用 Claude Code 2.1.289 跑過 validate 與 test，沒跑互動 session。請自己寫 observation.md：版本、spinner 原文、/tally 輸出、/plugin 那一行；不同就照實寫。

## 改一行字，看熱重載

session 不關，把 `ui.render` 的 `' · tool calls: '` 改成 `' · tools used: '` 並存檔。文件說預期 transcript 出現 first-mod 已重載的一行，下一次 spinner 變成 `Thinking · tools used: 1…`；請記下原文。

```javascript 修改 first-mod/hooks/register.js 的 ui.render 事件函式
    return next({ ...e, props: { ...e.props, suffix: ' · tools used: ' + calls + '…' } })
```

每次重載都再執行 `register`，所以 `calls` 歸零；跨重載保留的做法，文件指向 `$.state`。

## 用驗證器看 Claude Code 讀到什麼

`claude plugin validate` 對 manifest 與 hooks module 做載入時同一套靜態分析，不執行程式也不開 session。已在本課材料上執行過（符號與文件範例不同）：

```text 專案終端機：驗證 first-mod
claude plugin validate ./first-mod
```

```text 專案終端機：驗證輸出（容器實際輸出，節錄）
  > ./register.js hooks: session.start, tool.call, command.run{command=tally}, ui.render{component=Spinner}
  > ./register.js calls: $.command.register, $.ui.invalidate

√ Validation passed
```

`hooks:` 行是掛上的事件與篩選，`calls:` 行是呼叫的每個 mods API 方法。事件沒列在第一行，Claude Code 就不會呼叫它；拼成 `tool.calls` 會報 `"tool.calls" is not an event`。規則如下：

- mods API 呼叫要寫完整，如 `$.store.get('notes')`；`const ui = $.ui` 會報 `$.ui is used as a value`。
- 事件名要是字串字面值，用變數會報 `the event name passed to on() is not a string literal`。
- 只用相對路徑匯入目錄內的檔案，唯一的裸匯入是 `claude-code`；寫成 ES module，不用 `require`。

載入時 Claude Code 會把依你版本產生的 `.d.ts` 型別檔寫進 `.claude-plugin/types/`，文件說與頁面不一致時以它們為準。

## 寫一個不用 session 的測試

測試檔名以 `.test.ts` 結尾。這個測試觸發兩次工具呼叫，再執行 /tally。

```typescript 寫入 first-mod/tests/first-mod.test.ts
import { expect, test } from 'claude-code/testing'

test('/tally reports the tool calls the mod has seen', async ($, on) => {
  // Answer each tool call in Claude Code's place, so no tool runs
  on('tool.call', () => ({ result: 'ok' }))

  // Fire two tool calls, which the mod's tool.call hook counts
  await $.tool.call({ tool: 'Bash', command: 'ls' })
  await $.tool.call({ tool: 'Read', file_path: 'README.md' })

  // Run /tally and check the text its hook returns
  const answer = await $.command.run({ command: 'tally', args: '' })
  expect(answer.text).toBe('Claude has made 2 tool calls since this mod loaded')
})
```

測試的 `$` 扮演 Claude Code。`$.tool.call(...)` 先經過 mod 的 `tool.call` 事件函式，再交給 stub：`on('tool.call', () => ({ result: 'ok' }))` 代替 Claude Code 回答，所以沒有 `ls` 真的執行。stub 要在第一次呼叫 `$` 前登記。

```text 專案終端機：在 first-mod 目錄跑測試
claude plugin test
```

```text 專案終端機：測試輸出（容器實際輸出）
tests/first-mod.test.ts:
(pass) /tally reports the tool calls the mod has seen [72.16ms]

 1 pass
 0 fail
Ran 1 test across 1 file. [0.32s]
```

測試失敗時命令以狀態 1 結束，可進 CI。測試沒有觸發 `session.start`，所以 /tally 並未註冊卻仍通過；指令是否在清單裡，要靠互動 session 的紀錄。

## 安全與界線

mod 以你的權限在行程內執行：可讀寫你帳號能碰的檔案、啟動程式、發網路請求、讀環境變數與設定檔裡的 API key、看到每個提示與工具呼叫，也能在你被詢問前核准工具呼叫。它不在沙盒裡；文件的結論是只從信得過的作者安裝。

validate 的 calls 行是檢查點：文件說事件函式要碰到自己以外的東西，只能呼叫 mods API。first-mod 只呼叫 `$.command.register` 與 `$.ui.invalidate`，沒有檔案、行程或網路。安裝別人的 mod 前，可先對取得的目錄跑 validate，原始碼仍要讀。

`--plugin-dir` 載入的目錄是 protected path，請 Claude 修改時，default 與 acceptEdits 模式會逐次詢問你。分享給別人時，在 README 寫明你測試用的版本。

## 完成判準與小練習

完成判準：validate 的 hooks 行列出四個事件、calls 行列出兩個方法；plugin test 一個測試通過；熱重載後 spinner 文字改變有紀錄。前兩項本站在容器驗證過（2.1.289，2026-10-04），後兩項是文件預期，沒完成就標成待測。

故障練習請保存實際輸出：把 `'tool.call'` 改成 `'tool.calls'`，預期 `"tool.calls" is not an event`；改回後，把 `$.ui.invalidate('ui.render')` 改成先寫 `const ui = $.ui` 再呼叫，預期 `$.ui is used as a value`。最後改回原樣，重跑 validate 與 test。

小練習：替測試檔加第二個測試，不觸發工具呼叫就跑 /tally，預期 `Claude has made 0 tool calls since this mod loaded`。別台機器載不了時，讀[跨平台 Hook 排錯](article:claude-code-hook-portability-recovery)。
