# 本篇參考成果

目標：用無害案例觀察允許、詢問、拒絕與執行隔離。

交付：行為矩陣、測試目錄與設定還原檔。

判準：每個案例記錄預期及實際結果；Windows 原生與 WSL2 分開，不把 MD 當存取控制。

故障案例：某個工具路徑未受設定約束；標明適用工具與 OS，不承諾全面封鎖。

## 可以直接比較的檔案

reference 包含可執行的共用程式及本篇完成設定。用編輯器比較 starter 與 reference，
逐項閱讀差異；不要直接覆蓋自己的專案。對照 article.md 的逐步操作，核對程式結果。
對話、工具是否載入、帳號授權、手機畫面與外部 CI 結果必須現場填入，不能從參考檔推定通過。

## 已知假資料的預期

fixtures/tasks.json 共 3 筆：a、c 未完成，b 已完成；a、c 標題相同但 id 不同。
MCP list_tasks limit=2 回傳 a、b，nextOffset 為 2；get_task 查無 id 回傳 found=false、item=null。
result-ok.json 可通過結構驗證；error、bad-schema 與截斷資料必須失敗。
重複 run-job 使用同 id 與相同輸入回傳 reused=true；相同 id 改輸入必須失敗。
本機 HTTP 假服務：缺少 token 為 401、錯誤 token 為 403、read-demo 為 200；不是 OAuth。
Skill 的乾淨 diff 不應捏造缺陷；toggle.diff 與 render.diff 必須指出具體條件及影響。

## 讀者實測紀錄

請自行建立 observation.md，記錄版本、輸入、實際命令、退出碼、工具紀錄及未驗證項目。
本篇正文的完成判準全部有對應證據後，才可將自己的練習標為完成。
