# 65．長任務的上下文整理與交接文件

這份材料可獨立解壓縮使用，無需先完成其他篇章。正文在 article.md。
兩個專案都包含共用的六組工具；本篇主要使用 config-lab。
starter 是操作起點，reference 是檔案與配置參考，不是作者已替你完成帳號操作的證明。

1. 在編輯器開啟 starter，終端機切到該資料夾。
2. 使用 Node.js 22 以上；先執行 `node --test tests/model.test.mjs`。
3. 需要 MCP 或整套工具測試時，執行 `npm ci --ignore-scripts`，再執行 `npm test`。
4. Agent SDK 另在 automation/sdk 執行 `npm ci --ignore-scripts`。
5. 請閱讀 article.md 的輸入位置標籤、預期結果與停止方式。

第 85 篇 starter 故意含切換錯誤，核心測試預期失敗；其他篇的核心基準預期通過。
無效 JSON、故障 MCP 與錯誤設定是刻意附上的測試材料，不能把它們安裝成正式設定。
Claude、GitHub、遠端授權與手機步驟需要讀者自己的有效環境；本包不含任何登入資料。
不要把 run-data、權杖或工作階段識別碼提交到版本庫。
