# 開發驗證、多代理與跨裝置

每個 lesson ZIP 可獨立解壓縮；先讀各包 README 與 article.md。
