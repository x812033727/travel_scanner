export function addTodo(items, title, id) {
  const cleaned = title.trim();
  if (!cleaned || cleaned.length > 100) return items;
  return [...items, { id, title: cleaned, completed: false }];
}
export function toggleTodo(items, id) {
  return items.map(item => item.id === id ? { ...item, completed: !item.completed } : item);
}
export function removeTodo(items, id) {
  return items.filter(item => item.id !== id);
}

export function filterTodos(items, mode) {
  if (mode === 'active') return items.filter(item => !item.completed);
  if (mode === 'completed') return items.filter(item => item.completed);
  return items;
}
export function loadTodos(raw) {
  try {
    const value = JSON.parse(raw);
    if (!Array.isArray(value)) return [];
    const seen = new Set();
    return value.filter(item => {
      if (!item || typeof item.id !== 'string' || !item.id || seen.has(item.id)
          || typeof item.title !== 'string' || !item.title.trim() || item.title.length > 100
          || typeof item.completed !== 'boolean') return false;
      seen.add(item.id);
      return true;
    }).map(item => ({ id: item.id, title: item.title, completed: item.completed }));
  } catch { return []; }
}
